// Show Images on Image Button
const profileUploaderBtn = document.querySelector(".profile_uploader-btn");
const profiteInputButton = document.querySelector(".profile_input-button");
const profileImage = document.querySelector(".profile_image");

profileUploaderBtn.addEventListener("click", () => {
    profiteInputButton.click();
});

profiteInputButton.addEventListener("change", function () {
    const file = this.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = () => {
            const result = reader.result;
            profileImage.src = result;
        };
        reader.readAsDataURL(file);
    }
});

// validation
let user_name = document.getElementById("name");
let surname = document.getElementById("surname");
let age = document.getElementById("age");
let city = document.getElementById("city");
let email = document.getElementById("email");
let checkbox = document.getElementById("validationFormCheck1");
let pattern = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
let mailformat =/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

function form_validate() {
    var flag = validate();
    if (flag) {
        generateImage();
    }
}

//Live form validation
user_name.addEventListener("keyup", function (e) {
    if (user_name.value.match(pattern) || user_name.value.length != 0) {
        user_name.style.border = "3px solid #14A44D";
    } else {
        user_name.style.border = "3px solid #DC4C64";
    }
});

surname.addEventListener("keyup", function (e) {
    if (surname.value.match(pattern) || surname.value.length != 0) {
        surname.style.border = "3px solid #14A44D";
    } else {
        surname.style.border = "3px solid #DC4C64";
    }
});

age.addEventListener("keyup", function (e) {
    if ((age.value > 10 && age.value < 50) || age.value.length != 0) {
        age.style.border = "3px solid #14A44D";
    } else {
        age.style.border = "3px solid #DC4C64";
    }
});

city.addEventListener("keyup", function (e) {
    if (city.value.match(pattern) || age.value.length != 0) {
        city.style.border = "3px solid #14A44D";
    } else {
        city.style.border = "3px solid #DC4C64";
    }
});

email.addEventListener("keyup", function (e) {
    if (email.value.match(mailformat) || email.value.length != 0) {
        email.style.border = "3px solid #14A44D";
    } else {
        email.style.border = "3px solid #DC4C64";
    }
});
checkbox.addEventListener("change", (event) => {
    if (event.currentTarget.checked) {
        document.getElementById("checkbox_label").style.color = "#14A44D";
    } else {
        document.getElementById("checkbox_label").style.color = "#DC4C64";
    }
});

// Form validation
function validate() {
    var status = false;
    var inputImage = document.getElementById("image");
    var files = inputImage.files;

    if (files.length == 0) {
        alert("Please choose a file first...");
        return false;
    }

    if (user_name.value.match(pattern)) {
        user_name.style.border = "3px solid #14A44D";
        status = true;
    } else {
        user_name.style.border = "3px solid #DC4C64";
        status = false;
    }

    if (surname.value.match(pattern)) {
        surname.style.border = "3px solid #14A44D";
        status = true;
    } else {
        surname.style.border = "3px solid #DC4C64";
        status = false;
    }

    if (age.value > 10 && age.value < 50) {
        age.style.border = "3px solid #14A44D";
        status = true;
    } else {
        age.style.border = "3px solid #DC4C64";
        status = false;
    }
    if (city.value.match(pattern)) {
        city.style.border = "3px solid #14A44D";
        status = true;
    } else {
        city.style.border = "3px solid #DC4C64";
        status = false;
    }

    if (email.value.match(mailformat)) {
        email.style.border = "3px solid #14A44D";
        status = true;
    } else {
        email.style.border = "3px solid #DC4C64";
        status = false;
    }

    if (document.getElementById("validationFormCheck1").checked == true) {
        document.getElementById("checkbox_label").style.color = "#14A44D";
        return true;
    } else {
        document.getElementById("checkbox_label").style.color = "#DC4C64";
        return false;
    }

    return status;
}

const loginPopup = document.querySelector(".popup");
const close = document.querySelector(".close");
var loading = document.getElementById("loading");
var generats = document.getElementById("generats");
// Close the popup
close.addEventListener("click", function () {
    loginPopup.classList.remove("show");
});

function generateImage() {
    // Get the input image file
    var inputImage = document.getElementById("image").files[0];
    const profileImage = document.querySelector(".profile_image");

    // Reset form data
    document.getElementById("generate_form").reset();

    // Set the image button icon on upload image area.
    profileImage.src = "/static/public/Upload Button.png";

    // Show the Popup
    loginPopup.classList.add("show");

    // Create a FormData object to send the image to the server
    var formData = new FormData();
    formData.append("image", inputImage);

    // Send the image to the server for generation
    fetch("/generate", {
        method: "POST",
        body: formData,
    })
        .then((response) => response.json())
        .then((data) => {
            // Display the generated images 1
            var generatedImagesElement_1 =document.getElementById("generate_img_1");
            generatedImagesElement_1.innerHTML = "";

            // Display the generated images 2
            var generatedImagesElement_2 =document.getElementById("generate_img_2");
            generatedImagesElement_2.innerHTML = "";
            if (data.success) {
                if (data.data != null) {
                    var imageElement_1 = document.createElement("img");
                    var imageElement_2 = document.createElement("img");

                    loading.style.display = "none";
                    generats.style.display = "block";

                    imageElement_1.src = data.data[0];
                    imageElement_1.style.width = "155px";
                    imageElement_1.style.height = "165px";
                    imageElement_1.classList.add("img-fluid");
                    generatedImagesElement_1.appendChild(imageElement_1);

                    imageElement_2.src = data.data[1];
                    imageElement_2.style.width = "155px";
                    imageElement_2.style.height = "165px";
                    imageElement_2.classList.add("img-fluid");
                    generatedImagesElement_2.appendChild(imageElement_2);
                }
            } else {
                // Display error message
                var errorMessage = document.createElement("p");
                errorMessage.textContent = data.error;
                console.log(errorMessage);
            }
        })
        .catch((error) => console.error("Error:", error));
}


const section = document.querySelector(".share_popup"),
    overlay = document.querySelector(".overlay"),
    showBtn = document.querySelector(".show-modal");

showBtn.addEventListener("click", () => section.classList.add("active"));

overlay.addEventListener("click", () =>
    section.classList.remove("active")
);
