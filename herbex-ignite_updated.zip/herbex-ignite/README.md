1. Clone the repository and enter that directory

`git clone `

3. Create a virtual environment 

`python3 -m venv hi-venv`

4. Activate the environment

`source hi-venv/bin/activate`
    
5. Install the requirments

`pip install -r requirements.txt`

6. Launch the server

`flask run`